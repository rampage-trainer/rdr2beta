--- Overview ----
Rampage is a Trainer / Modification for Red Dead Redemption 2 Story Mode

--- How to Install ---
Extract the .zip file and put the Rampage.asi into your RDR2 Directory.
Make sure you have the latest version of Alexander Blades ScriptHookRDR2 plugin (ScriptHookRDR2.dll & dinput8.dll)
The Trainer will unpack all necessary files on startup after thaat you can copy files into the RampageFiles folder.

If RDR2 is installed on your main drive (C:) don`t forget to start the game as Administrator in order to be able to write files.

--- Troubleshooting ---
If you encounter any issues while loading such as "Settings.ini missing" or "Hotkey.ini missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart RDR2.

--- Known issues ---
Options that access RDR`s entity pools like Local Peds & Local Vehicle options, Black hole etc. tend to crash if there are to many entites.
To prevent crashing because of too many spawned objects try to delete old ones first and free the memory by deleting world vehicles / peds.

--- Important Things ---
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the Option and enter your new hotkey inside the window.

Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

If you make any changes like changeing the colors or other settings in order to save them you need to manually save them
under Settings -> Load / Save.

--- Controls ---
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F5
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Int, Float, Vector) =  Right/Left Arrow key or Numpad4  and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5

--- Terms & Rules ---
-Rampage is a Trainer for RDR2 Story Mode only that means this Trainer can only be used in RDR2 Offline.

-It is not allowed to try to use this Online or to use other third party tools to get it working. 

-This will result in a Ban. 

-Since this Trainer uses Alexander Blade's ScriptHookRDR2 Plugin to load into RDR2 it wont't allow you to go online with it.

-You are not allowed to reupload this Trainer anywhere. You are not allowed to try to reverse this Trainer or to modify its code.

-This Trainer is completly free, so you are not allowed to use this in any commercial way. That means it is forbidden to sell this.

--- Changelog ---

Version 1.0
-> Initial Release

--- Credits ---

RDR2 Modding Resources

alloc8or Native DB
